<?php
include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'accordion/form.php');
include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'accordion/output.php');

include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'callout/form.php');
include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'callout/output.php');

include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'map/form.php');
include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'map/output.php');

include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'blog_grid/form.php');
include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'blog_grid/output.php');

include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'video/form.php');
include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'video/output.php');

include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'toggle/form.php');
include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'toggle/output.php');

include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'text/form.php');
include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'text/output.php');

include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'textblock/form.php');
include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'textblock/output.php');

include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'tab/form.php');
include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'tab/output.php');

include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'testimonial_slideshow/form.php');
include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'testimonial_slideshow/output.php');

include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'slideshow/form.php');
include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'slideshow/output.php');

include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'testimonial_grid/form.php');
include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'testimonial_grid/output.php');

include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'testimonial_carousel/form.php');
include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'testimonial_carousel/output.php');

include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'portfolio_slideshow/form.php');
include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'portfolio_slideshow/output.php');

include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'portfolio_grid/form.php');
include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'portfolio_grid/output.php');

include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'portfolio_carousel/form.php');
include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'portfolio_carousel/output.php');

include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'people_carousel/form.php');
include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'people_carousel/output.php');

include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'people_grid/form.php');
include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'people_grid/output.php');

include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'people_slideshow/form.php');
include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'people_slideshow/output.php');

include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'logo_grid/form.php');
include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'logo_grid/output.php');

include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'logo_slideshow/form.php');
include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'logo_slideshow/output.php');

include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'logo_carousel/form.php');
include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'logo_carousel/output.php');

include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'audio/form.php');
include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'audio/output.php');

include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'gallery_single/form.php');
include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'gallery_single/output.php');

include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'gallery_archive/form.php');
include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'gallery_archive/output.php');

include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'counter_box/form.php');
include(TALLYKIT_FRONTPAGE_COMPONENT_BLOCKS_DRI.'counter_box/output.php');