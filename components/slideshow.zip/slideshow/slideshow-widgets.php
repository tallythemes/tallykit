<?php
/*************************** Widgets *****************************
 *
 * Register Widgets
 *
 * @since TallyKit (1.0)
 *
 * @uses class acoc_widget_register  
**/