<div class="tk_slideshow_caption_left_warp">
	<?php include(tallykit_slideshow_template_path('dri').'content/content-content.php'); ?>
</div>