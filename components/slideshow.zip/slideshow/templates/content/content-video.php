<div class="tk_slideshow_video_holder">
	<div class="tk_slideshow_the_video">
		<?php echo wp_oembed_get($slider_item['video']); ?>
    </div>
</div>