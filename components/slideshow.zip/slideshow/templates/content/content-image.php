<div class="tk_slideshow_image_holder">
	<img src="<?php echo $slider_item['image']; ?>" alt="<?php echo $slider_item['title']; ?>" />
</div>