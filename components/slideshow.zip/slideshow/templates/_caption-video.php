<div class="tk_slideshow_content_video_warp">
	<?php include(tallykit_slideshow_template_path('dri').'content/content-content.php'); ?>
    <?php include(tallykit_slideshow_template_path('dri').'content/content-video.php'); ?>
</div>