<div class="tk_slideshow_image_content_warp">
	<?php include(tallykit_slideshow_template_path('dri').'content/content-image.php'); ?>
	<?php include(tallykit_slideshow_template_path('dri').'content/content-content.php'); ?>
</div>