<div class="tk_slideshow_video_content_warp">
    <?php include(tallykit_slideshow_template_path('dri').'content/content-video.php'); ?>
    <?php include(tallykit_slideshow_template_path('dri').'content/content-content.php'); ?>
</div>