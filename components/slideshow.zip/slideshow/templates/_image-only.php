<div class="tk_slideshow_image_only_warp">
	<?php include(tallykit_slideshow_template_path('dri').'content/content-image.php'); ?>
</div>